@echo off
REM ---------------------------------------------------------------
REM  ClaudeMigrate V1.17 - entry point inside Aigoo_V1.17.zip
REM  Extract the whole zip first, then double-click this file.
REM  Must stay pure ASCII, no BOM.
REM ---------------------------------------------------------------
cd /d "%~dp0"
title ClaudeMigrate V1.17
REM Opened from the Explorer zip window: Windows runs it from a temp copy such as Temp\<guid>_Name.zip.69c
echo "%~dp0" | "%SystemRoot%\System32\findstr.exe" /i /r "\\Temp\\.*\.zip\." >nul && goto notextracted
if not exist "%~dp0Install_V1.17.ps1" goto notextracted
if not exist "%~dp0payload.zip" goto notextracted
echo.
echo   If PowerShell shows a security warning for Install_V1.17.ps1,
echo   type R and press Enter to run it.
echo.
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Unrestricted -File "%~dp0Install_V1.17.ps1" -Payload "%~dp0payload.zip"
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
  echo   RESULT: OK - all required checks passed.
) else if "%RC%"=="99" (
  echo   RESULT: INSTALL STOPPED by an unexpected error - see the red lines above and the log on the Desktop.
) else (
  echo   RESULT: %RC% required check^(s^) FAILED - see red lines above and the log on the Desktop.
)
echo.
pause
exit /b 0

:notextracted
echo.
echo   The zip is not extracted, or installer files are missing next to setup.cmd.
echo   Close this window. Right-click Aigoo_V1.17.zip, choose Extract All, then run setup.cmd
echo   from the extracted folder.
echo.
pause
exit /b 1
