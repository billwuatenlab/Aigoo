# ---------------------------------------------------------------
#  ClaudeMigrate V1.17 - INSTALL (runs on the NEW machine)
#
#  Launched by setup.cmd after Aigo_V1.17.zip is extracted.
#  Modes (asked when an existing setup is found; -Mode overrides):
#    Full  = reinstall Claude Code and Orca, restore everything incl. claude-mem.db
#    Patch = install only what is missing, update settings/hooks/skills/CLAUDE.md,
#            memory files only if newer, keep this machine's claude-mem.db
#  Steps:
#    1. install Git / Python 3.13 / Node.js LTS / Bun / uv / gh (only if missing):
#       winget first; if winget is unavailable or fails, official per-user downloads
#    2. install Claude Code (official install.ps1, npm as fallback)
#    3. back up any existing ~/.claude, ~/.orca/agent-hooks, ~/.claude-mem
#    4. restore payload (settings, CLAUDE.md, hooks, skills, memory,
#       Orca agent-hooks, claude-mem database)
#    5. rewrite hard-coded paths of the old machine to this machine
#    6. install Orca (latest from GitHub, only if missing)
#    7. install claude-mem plugin
#    8. ask for a start folder and create Desktop\Claude Code.lnk
#    9. print checklist; exit code = number of failed required checks
#
#  Pure ASCII on purpose (PS 5.1 + no BOM = ANSI; ASCII is always safe).
# ---------------------------------------------------------------
param(
    [string]$Payload = (Join-Path $PSScriptRoot 'payload.zip'),
    [switch]$SkipApps,       # skip winget / Claude / Orca installs (restore only)
    [switch]$NoShortcut,     # do not ask for a folder / create the desktop shortcut (dry runs)
    [ValidateSet('Ask', 'Full', 'Patch')]
    [string]$Mode = 'Ask',
    [string]$TargetHome = $env:USERPROFILE
)

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
# winget and the Claude installer print UTF-8; PowerShell 5.1 would decode it with the system code page.
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}

# >>> edition (public Aigoo package)
$Edition = 'Aigoo'
$RepoWeb = 'https://github.com/billwuatenlab/Aigoo'
$MarkerName = '.aigoo_version'
# <<< edition
$IsPublic = ($Edition -eq 'Aigoo')

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$log = Join-Path ([Environment]::GetFolderPath('Desktop')) "${Edition}_V1.17_$stamp.log"
$issueUrl = "$RepoWeb/issues/new"
Start-Transcript -Path $log -Force | Out-Null

# Any unexpected terminating error still leaves a complete log behind.
trap {
    Write-Host "  UNEXPECTED ERROR: $($_ | Out-String)" -ForegroundColor Red
    Write-Host "  Log: $log" -ForegroundColor Yellow
    Write-Host "  To fix this from another PC, attach the log to a new issue: $issueUrl" -ForegroundColor Yellow
    try { Stop-Transcript | Out-Null } catch {}
    exit 99
}

function Say($msg, $color = 'Gray') { Write-Host "  $msg" -ForegroundColor $color }
function Step($msg) { Write-Host ''; Write-Host "== $msg" -ForegroundColor Cyan }

# Start-Transcript misses native program output unless it goes through the host.
function Log-Native {
    process {
        $s = "$_".Trim()
        if ($s -match '\w') { Say $s 'DarkGray' }
    }
}

function Refresh-Path {
    $m = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $u = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = "$m;$u;$TargetHome\.local\bin;$TargetHome\.bun\bin;$env:APPDATA\npm;$env:LOCALAPPDATA\Microsoft\WindowsApps"
}

function Add-UserPath($dir) {
    $u = [Environment]::GetEnvironmentVariable('Path', 'User')
    $parts = @($u -split ';' | Where-Object { $_ })
    if ($parts -notcontains $dir) {
        [Environment]::SetEnvironmentVariable('Path', (($parts + $dir) -join ';'), 'User')
        Say "Added to user PATH: $dir"
    }
}

function Find-Claude {
    $native = Join-Path $TargetHome '.local\bin\claude.exe'
    if (Test-Path -LiteralPath $native) { return $native }
    foreach ($n in 'claude.exe', 'claude.cmd') {
        $c = Get-Command $n -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($c) { return $c.Source }
    }
    return $null
}

function Write-Utf8NoBom($path, $text) {
    [IO.File]::WriteAllText($path, $text, (New-Object Text.UTF8Encoding($false)))
}

function Robo($src, $dst, [string[]]$extra = @()) {
    if (-not (Test-Path -LiteralPath $src)) { return $true }
    & robocopy $src $dst /E /R:1 /W:1 /NFL /NDL /NJH /NJS /NP @extra | Out-Null
    return ($LASTEXITCODE -lt 8)
}

function Find-Python313 {
    $c = @(
        "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe",
        "$env:ProgramFiles\Python313\python.exe"
    )
    foreach ($p in $c) { if (Test-Path -LiteralPath $p) { return $p } }
    if (Get-Command py -ErrorAction SilentlyContinue) {
        # An old py.exe prints "Python 3.13 not found!" and its version list to stdout,
        # so accept only a line that is the path of an existing python.exe.
        foreach ($line in @(& py -3.13 -X utf8 -c "import sys;print(sys.executable)" 2>$null)) {
            $p = "$line".Trim()
            if ($p -match '\\python\.exe$' -and (Test-Path -LiteralPath $p)) { return $p }
        }
    }
    return $null
}

# TopMost on an owner that is never shown does nothing, and the dialog can open behind
# the console. Show a tiny off-screen owner (with a taskbar button) so it opens in front.
function New-DialogOwner($title) {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    Say "A choice window is open: '$title'. If you don't see it, press Alt+Tab or check the taskbar." 'Yellow'
    $f = New-Object System.Windows.Forms.Form
    $f.Text = $title
    $f.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
    $f.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual
    $f.Location = New-Object System.Drawing.Point(-32000, -32000)
    $f.Size = New-Object System.Drawing.Size(1, 1)
    $f.TopMost = $true
    $f.Show()
    $f.Activate()
    [System.Windows.Forms.Application]::DoEvents()
    return $f
}

function Ensure-Winget {
    if (Get-Command winget -ErrorAction SilentlyContinue) { return $true }
    Say 'winget not found - trying to register App Installer ...' 'Yellow'
    try {
        Add-AppxPackage -RegisterByFamilyName -MainPackage Microsoft.DesktopAppInstaller_8wekyb3d8bbwe -ErrorAction Stop
    } catch {
        Say "App Installer registration failed: $($_.Exception.Message)" 'Yellow'
    }
    Refresh-Path
    if (Get-Command winget -ErrorAction SilentlyContinue) { Say 'winget is ready' 'Green'; return $true }
    Say 'winget is not available - using official downloads instead' 'Yellow'
    return $false
}

# Retry only errors that may pass on their own: HTTP 5xx / 408 / 429, timeouts, dropped connections.
# A 404 or any other client error fails at once.
function Test-TransientError($err) {
    $ex = $err.Exception
    while ($ex) {
        if ($ex -is [System.Net.WebException]) {
            if ($ex.Response -and $ex.Response.StatusCode) {
                $code = [int]$ex.Response.StatusCode
                return ($code -ge 500 -or $code -eq 408 -or $code -eq 429)
            }
            return $true
        }
        if ($ex -is [System.IO.IOException] -or $ex -is [System.TimeoutException]) { return $true }
        $ex = $ex.InnerException
    }
    return $false
}

function Invoke-WithRetry($what, [scriptblock]$action) {
    $waits = @(10, 30, 60)
    for ($i = 0; ; $i++) {
        try {
            return (& $action)
        } catch {
            if ($i -ge $waits.Count -or -not (Test-TransientError $_)) { throw }
            Say "$what failed (attempt $($i + 1) of $($waits.Count + 1)): $($_.Exception.Message)" 'Yellow'
            Say "Retrying in $($waits[$i]) s ..." 'Yellow'
            Start-Sleep -Seconds $waits[$i]
        }
    }
}

# winget reports a download failure as an HRESULT: 0x8019xxxx carries the HTTP status,
# 0x80072Exx is a WinINet network error, 0x8A150008 is winget's own "download failed".
function Test-WingetTransient($exitCode) {
    $h = ([int]$exitCode).ToString('X8')
    if ($h -match '^80190([0-9A-F]{3})$') {
        $status = [Convert]::ToInt32($Matches[1], 16)
        return ($status -ge 500 -or $status -eq 408 -or $status -eq 429)
    }
    return ($h -match '^80072E' -or $h -eq '8A150008')
}

# Returns winget's exit code. A network failure is tried once more; a cancelled UAC prompt is not.
function Invoke-Winget($id, $label, [string[]]$extra = @()) {
    for ($try = 1; ; $try++) {
        Say "Installing $label ($id) ..." 'Yellow'
        & winget install -e --id $id --accept-source-agreements --accept-package-agreements --silent @extra 2>&1 | Log-Native
        $code = $LASTEXITCODE
        Say "winget exit code for ${label}: $code"
        if ($code -eq 0 -or $try -ge 2 -or -not (Test-WingetTransient $code)) { return $code }
        Say 'winget download failed with a network error - retrying in 30 s ...' 'Yellow'
        Start-Sleep -Seconds 30
    }
}

function Download-Verified($url, $dest, $sha256) {
    Say "Downloading $url ..." 'Yellow'
    Say '(no progress is shown; a slow connection can take several minutes)' 'DarkGray'
    Invoke-WithRetry 'Download' { Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing -ErrorAction Stop }
    if ($sha256) {
        if ((Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash -ne $sha256) {
            Remove-Item -LiteralPath $dest -Force -ErrorAction SilentlyContinue
            throw "SHA256 mismatch for $url"
        }
        Say 'SHA256 verified'
    }
}

function Get-GitHubAsset($repo, $pattern) {
    $rel = Invoke-WithRetry 'GitHub release lookup' {
        Invoke-RestMethod -Uri "https://api.github.com/repos/$repo/releases/latest" -UseBasicParsing -ErrorAction Stop
    }
    $a = $rel.assets | Where-Object { $_.name -match $pattern } | Select-Object -First 1
    if (-not $a) { throw "No release file matching $pattern in $repo" }
    if ($a.digest -notmatch '^sha256:') { throw "No SHA256 digest published for $($a.name)" }
    $dest = Join-Path $dlDir $a.name
    Download-Verified $a.browser_download_url $dest ($a.digest -replace '^sha256:', '')
    return $dest
}

function Expand-ToNew($zip) {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $out = Join-Path $dlDir ([IO.Path]::GetFileNameWithoutExtension($zip))
    [IO.Compression.ZipFile]::ExtractToDirectory($zip, $out)
    return $out
}

function Copy-Exes($from, $to) {
    New-Item -ItemType Directory -Force -Path $to | Out-Null
    Get-ChildItem -LiteralPath $from -Recurse -Filter '*.exe' | Copy-Item -Destination $to -Force
    Add-UserPath $to
}

# All of these install for the current user only, so they need no UAC prompt.
function Install-GitDirect {
    $exe = Get-GitHubAsset 'git-for-windows/git' '^PortableGit-.*-64-bit\.7z\.exe$'
    $dir = Join-Path $env:LOCALAPPDATA 'Programs\Git'
    $p = Start-Process -FilePath $exe -ArgumentList '-y', "-o`"$dir`"" -Wait -PassThru
    Say "PortableGit exit code: $($p.ExitCode)"
    Add-UserPath (Join-Path $dir 'cmd')
}

function Install-PythonDirect {
    $v = '3.13.17'
    $exe = Join-Path $dlDir "python-$v-amd64.exe"
    Download-Verified "https://www.python.org/ftp/python/$v/python-$v-amd64.exe" $exe $null
    $sig = Get-AuthenticodeSignature -LiteralPath $exe
    if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'Python Software Foundation') {
        throw "Python installer signature check failed: $($sig.Status)"
    }
    Say 'Signature verified: Python Software Foundation'
    $p = Start-Process -FilePath $exe -ArgumentList '/quiet', 'InstallAllUsers=0', 'PrependPath=1', 'InstallLauncherAllUsers=0' -Wait -PassThru
    Say "Python installer exit code: $($p.ExitCode)"
}

function Install-NodeDirect {
    $lts = Invoke-WithRetry 'Node.js release lookup' {
        Invoke-RestMethod -Uri 'https://nodejs.org/dist/index.json' -UseBasicParsing -ErrorAction Stop
    } | ForEach-Object { $_ } | Where-Object { $_.lts } | Select-Object -First 1
    if (-not $lts) { throw 'Could not find a Node.js LTS release' }
    $v = $lts.version
    $name = "node-$v-win-x64.zip"
    $sums = (Invoke-WithRetry 'Node.js checksum lookup' {
        Invoke-WebRequest -Uri "https://nodejs.org/dist/$v/SHASUMS256.txt" -UseBasicParsing -ErrorAction Stop
    }).Content
    $m = [regex]::Match($sums, "(?m)^([0-9a-f]{64})\s+$([regex]::Escape($name))\s*$")
    if (-not $m.Success) { throw "No SHA256 published for $name" }
    $zip = Join-Path $dlDir $name
    Download-Verified "https://nodejs.org/dist/$v/$name" $zip $m.Groups[1].Value
    $out = Expand-ToNew $zip
    $dir = Join-Path $env:LOCALAPPDATA 'Programs\nodejs'
    if (-not (Robo (Join-Path $out "node-$v-win-x64") $dir)) { throw 'Copying Node.js failed' }
    Add-UserPath $dir
}

function Install-BunDirect {
    $out = Expand-ToNew (Get-GitHubAsset 'oven-sh/bun' '^bun-windows-x64\.zip$')
    Copy-Exes $out (Join-Path $TargetHome '.bun\bin')
}

# RustDesk has no winget package, and its MSI installs for all users, so it asks for UAC.
function Install-RustDeskDirect {
    $msi = Get-GitHubAsset 'rustdesk/rustdesk' '^rustdesk-[\d.]+-x86_64\.msi$'
    $sig = Get-AuthenticodeSignature -LiteralPath $msi
    if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'PURSLANE') {
        throw "RustDesk installer signature check failed: $($sig.Status)"
    }
    Say 'Signature verified: PURSLANE (RustDesk publisher)'
    Say 'Installing RustDesk - click Yes on the UAC prompt ...' 'Yellow'
    $p = Start-Process -FilePath 'msiexec.exe' -ArgumentList '/i', "`"$msi`"", '/qn', 'INSTALLPRINTER=N' -Verb RunAs -Wait -PassThru
    Say "RustDesk installer exit code: $($p.ExitCode)"
}

function Install-UvDirect {
    $out = Expand-ToNew (Get-GitHubAsset 'astral-sh/uv' '^uv-x86_64-pc-windows-msvc\.zip$')
    Copy-Exes $out (Join-Path $TargetHome '.local\bin')
}

# Optional: Orca uses gh for GitHub issues, pull requests and CI status.
function Install-GhDirect {
    $out = Expand-ToNew (Get-GitHubAsset 'cli/cli' '^gh_[\d.]+_windows_amd64\.zip$')
    Copy-Exes $out (Join-Path $env:LOCALAPPDATA 'Programs\GitHub CLI')
}

function Test-Prereq($label, [scriptblock]$present) {
    # A failed check must not end the whole install: treat it as not installed.
    try {
        return [bool](& $present)
    } catch {
        Say "Could not check ${label}: $($_.Exception.Message)" 'Yellow'
        return $false
    }
}

function Install-Prereq($id, $label, [scriptblock]$present, [scriptblock]$direct, [string[]]$extra = @()) {
    if (Test-Prereq $label $present) { Say "$label already installed - skip" 'DarkGray'; return }
    if ($hasWinget -and $id) {
        Invoke-Winget $id $label $extra | Out-Null
        Refresh-Path
        if (Test-Prereq $label $present) { return }
        Say "winget did not install $label - trying the official download" 'Yellow'
    }
    try {
        & $direct
    } catch {
        Say "Official download of $label failed: $($_.Exception.Message)" 'Red'
    }
    Refresh-Path
    if (Test-Prereq $label $present) { Say "$label installed" 'Green' } else { Say "$label install FAILED" 'Red' }
}

function Stop-ClaudeMemWorker {
    # The worker runs under bun/node, so match the command line, not the exe path.
    # Dry runs on a fake home leave the real worker alone.
    if ($TargetHome -ne $env:USERPROFILE) { return }
    $running = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -like '*claude-mem*worker-service*' -and $_.ProcessId -ne $PID })
    foreach ($w in $running) {
        Say "Stopping claude-mem worker (pid $($w.ProcessId))" 'Yellow'
        Stop-Process -Id $w.ProcessId -Force -ErrorAction SilentlyContinue
    }
    if ($running.Count -gt 0) { Start-Sleep -Seconds 2 }
}

# Public Aigoo replaces the internal AIGO edition: its memory, claude-mem database,
# update hook and backups are deleted without a prompt and without a backup.
# Programs (Git, Claude Code, Orca, ...) are kept. Returns $true if AIGO was found.
function Remove-AigoInternal {
    $c = Join-Path $TargetHome '.claude'
    if (-not (Test-Path -LiteralPath (Join-Path $c '.aigo_version'))) { return $false }
    Step 'Internal AIGO found - removing it before installing Aigoo'
    Stop-ClaudeMemWorker
    $gone = @()
    $gone += @(Get-ChildItem -LiteralPath (Join-Path $c 'projects') -Directory -ErrorAction SilentlyContinue |
        ForEach-Object { Join-Path $_.FullName 'memory' } | Where-Object { Test-Path -LiteralPath $_ })
    $m = Join-Path $TargetHome '.claude-mem'
    $gone += @(Get-ChildItem -LiteralPath $m -Filter 'claude-mem.db*' -File -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName })
    $gone += @((Join-Path $m 'corpora'), (Join-Path $m 'backfill.json'),
        (Join-Path $c 'hooks\aigo_update_check.ps1'), (Join-Path $c 'hooks\aigo_update.ps1'),
        (Join-Path $c '.aigo_update_check') | Where-Object { Test-Path -LiteralPath $_ })
    # Earlier AIGO installs and updates left full copies (with memory) as <dir>.bak-<time>.
    foreach ($pat in '.claude.bak-*', '.claude-mem.bak-*') {
        $gone += @(Get-ChildItem -LiteralPath $TargetHome -Directory -Filter $pat -Force -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName })
    }
    $gone += @(Get-ChildItem -LiteralPath (Join-Path $TargetHome '.orca') -Directory -Filter 'agent-hooks.bak-*' -Force -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName })
    $failed = 0
    foreach ($g in $gone) {
        Remove-Item -LiteralPath $g -Recurse -Force -ErrorAction SilentlyContinue
        if (Test-Path -LiteralPath $g) { Say "Could not delete $g" 'Red'; $failed++ } else { Say "Deleted $g" 'DarkGray' }
    }
    # The marker goes last, so a run that could not delete everything finds AIGO again next time.
    if ($failed -eq 0) { Remove-Item -LiteralPath (Join-Path $c '.aigo_version') -Force -ErrorAction SilentlyContinue }
    Say "Internal AIGO removed ($($gone.Count) items, $failed failed). Programs are kept." $(if ($failed) { 'Red' } else { 'Green' })
    return $true
}

Write-Host ''
Write-Host "  ClaudeMigrate V1.17 ($Edition) - one-click install" -ForegroundColor White
Write-Host '  -------------------------------------' -ForegroundColor White
Say "Target home : $TargetHome"
Say "Log file    : $log"
Say "Windows     : $([Environment]::OSVersion.VersionString)"
Say "PowerShell  : $($PSVersionTable.PSVersion)"
Say "Computer    : $env:COMPUTERNAME"

if (-not (Test-Path -LiteralPath $Payload)) {
    Say "payload.zip not found at $Payload" 'Red'
    Stop-Transcript | Out-Null
    exit 1
}

# ---------- install mode ----------
$versionMarker = Join-Path $TargetHome ".claude\$MarkerName"
if ($IsPublic -and (Remove-AigoInternal) -and $Mode -eq 'Ask') {
    $Mode = 'Patch'   # keep the programs that AIGO installed
}
if ($Mode -eq 'Ask') {
    if (Test-Path -LiteralPath (Join-Path $TargetHome '.claude\hooks\stage_gate.py')) {
        $prevVersion = 'unknown'
        if (Test-Path -LiteralPath $versionMarker) { $prevVersion = (Get-Content -LiteralPath $versionMarker -Raw).Trim() }
        $text = "An existing $Edition setup was found (version $prevVersion).`n`n" +
            "YES = PATCH UPDATE`n  Install only missing programs. Update settings, hooks, skills and CLAUDE.md. " +
            "Replace memory files only with newer ones. Keep this PC's claude-mem database.`n`n" +
            "NO = FULL REINSTALL`n  Reinstall Claude Code and Orca. Restore everything, including the claude-mem database " +
            "(the current one is backed up first).`n`n" +
            "CANCEL = exit, change nothing."
        try {
            $owner = New-DialogOwner "$Edition V1.17 - install mode"
            $answer = [System.Windows.Forms.MessageBox]::Show($owner, $text, "$Edition V1.17 - install mode",
                [System.Windows.Forms.MessageBoxButtons]::YesNoCancel, [System.Windows.Forms.MessageBoxIcon]::Question)
            $owner.Dispose()
        } catch {
            Say "Mode dialog failed ($($_.Exception.Message)) - using Patch, the safer mode" 'Yellow'
            $answer = 'Yes'
        }
        if ("$answer" -eq 'Cancel') {
            Say 'Cancelled - nothing changed.' 'Yellow'
            Stop-Transcript | Out-Null
            exit 0
        }
        $Mode = if ("$answer" -eq 'No') { 'Full' } else { 'Patch' }
    } else {
        $Mode = 'Full'
    }
}
Say "Install mode: $Mode" 'White'

# ---------- 1. prerequisites ----------
Refresh-Path
$rustDeskExe = Join-Path $env:ProgramFiles 'RustDesk\RustDesk.exe'
if (-not $SkipApps) {
    Step '1/8  Prerequisites (winget, official downloads as fallback)'
    $dlDir = Join-Path $env:TEMP "cm16d_$stamp"
    New-Item -ItemType Directory -Force -Path $dlDir | Out-Null
    $hasWinget = Ensure-Winget
    Install-Prereq 'Git.Git' 'Git for Windows' { [bool](Get-Command git -ErrorAction SilentlyContinue) } { Install-GitDirect }
    Install-Prereq 'Python.Python.3.13' 'Python 3.13' { [bool](Find-Python313) } { Install-PythonDirect } @('--scope', 'user')
    Install-Prereq 'OpenJS.NodeJS.LTS' 'Node.js LTS' { [bool](Get-Command node -ErrorAction SilentlyContinue) } { Install-NodeDirect }
    Install-Prereq 'Oven-sh.Bun' 'Bun (claude-mem)' { [bool](Get-Command bun -ErrorAction SilentlyContinue) } { Install-BunDirect }
    Install-Prereq 'astral-sh.uv' 'uv (claude-mem)' { [bool](Get-Command uv -ErrorAction SilentlyContinue) } { Install-UvDirect }
    Install-Prereq 'GitHub.cli' 'GitHub CLI (gh, optional)' { [bool](Get-Command gh -ErrorAction SilentlyContinue) } { Install-GhDirect }
    Install-Prereq '' 'RustDesk' { Test-Path -LiteralPath $rustDeskExe } { Install-RustDeskDirect }
    Remove-Item -LiteralPath $dlDir -Recurse -Force -ErrorAction SilentlyContinue
}

# ---------- 2. Claude Code ----------
$claudeExe = Find-Claude
if (-not $SkipApps) {
    Step '2/8  Claude Code'
    if ($claudeExe -and $Mode -ne 'Full') {
        Say "Claude Code already installed ($claudeExe) - skip" 'DarkGray'
    } else {
        Say 'Installing Claude Code (https://claude.ai/install.ps1) ...' 'Yellow'
        # Save to a file and run it in this session: no piping into iex, no child powershell.exe,
        # and install.ps1 keeps the TLS 1.2 setting it needs (a child process would not inherit it).
        # exit inside install.ps1 ends only that script and sets $LASTEXITCODE.
        $claudeInstaller = Join-Path $env:TEMP "claude-install_$stamp.ps1"
        try {
            Invoke-WithRetry 'Claude Code installer download' {
                Invoke-WebRequest -Uri 'https://claude.ai/install.ps1' -OutFile $claudeInstaller -UseBasicParsing -ErrorAction Stop
            }
            & $claudeInstaller 2>&1 | Log-Native
            Say "install.ps1 exit code: $LASTEXITCODE"
        } catch {
            Say "install.ps1 failed: $($_.Exception.Message)" 'Red'
        }
        Remove-Item -LiteralPath $claudeInstaller -Force -ErrorAction SilentlyContinue
        Refresh-Path
        $claudeExe = Find-Claude
        if (-not $claudeExe) {
            Say 'Official installer did not produce claude - trying npm ...' 'Yellow'
            if (Get-Command npm -ErrorAction SilentlyContinue) {
                & npm install -g '@anthropic-ai/claude-code' 2>&1 | Log-Native
                Say "npm exit code: $LASTEXITCODE"
                Refresh-Path
                $claudeExe = Find-Claude
            } else {
                Say 'npm not found - cannot use the fallback' 'Red'
            }
        }
        if ($claudeExe) { Say "Claude Code installed: $claudeExe" 'Green' }
        else { Say 'Claude Code install FAILED (official installer and npm)' 'Red' }
    }
    # New terminals must find claude and bun, not only this window.
    if ($claudeExe) { Add-UserPath (Split-Path -Parent $claudeExe) }
    $bunCmd = Get-Command bun -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($bunCmd) { Add-UserPath (Split-Path -Parent $bunCmd.Source) }
}
if (-not $claudeExe) { $claudeExe = Join-Path $TargetHome '.local\bin\claude.exe' }

# ---------- 3. unpack + backup ----------
Step '3/8  Unpack payload and back up existing settings'
$work = Join-Path $env:TEMP "cm16i_$stamp"
New-Item -ItemType Directory -Force -Path $work | Out-Null
Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::ExtractToDirectory($Payload, $work)
$manifest = Get-Content -LiteralPath (Join-Path $work 'manifest.json') -Raw | ConvertFrom-Json
Say "Package from $($manifest.sourceMachine) built $($manifest.built)"

$targets = @(
    @{ name = '.claude';            path = Join-Path $TargetHome '.claude' },
    @{ name = '.orca\agent-hooks';  path = Join-Path $TargetHome '.orca\agent-hooks' },
    @{ name = '.claude-mem';        path = Join-Path $TargetHome '.claude-mem' }
)
foreach ($t in $targets) {
    if (Test-Path -LiteralPath $t.path) {
        $bak = "$($t.path).bak-$stamp"
        $ok = Robo $t.path $bak @('/XD', 'logs', 'cache', 'file-history', 'shell-snapshots', 'paste-cache')
        if ($ok) { Say "Backed up $($t.name) -> $bak" } else { Say "Backup of $($t.name) FAILED" 'Red' }
    }
}

# ---------- 4. restore ----------
Step '4/8  Restore settings, hooks, skills, memory, Orca hooks, claude-mem'
$claudeDir = Join-Path $TargetHome '.claude'
$memDir = Join-Path $TargetHome '.claude-mem'
$orcaHooks = Join-Path $TargetHome '.orca\agent-hooks'

$r2 = Robo (Join-Path $work 'orca-agent-hooks') $orcaHooks
if ($Mode -eq 'Patch') {
    $r1a = Robo (Join-Path $work 'claude') $claudeDir @('/XD', (Join-Path $work 'claude\projects'))
    $r1b = Robo (Join-Path $work 'claude\projects') (Join-Path $claudeDir 'projects') @('/XO')   # memory: newer only
    $r1 = $r1a -and $r1b
    if (Test-Path -LiteralPath (Join-Path $memDir 'claude-mem.db')) {
        $r3 = Robo (Join-Path $work 'claude-mem') $memDir @('/XF', 'claude-mem.db', 'claude-mem.db-wal', 'claude-mem.db-shm')
        Say "Kept this PC's claude-mem database"
    } else {
        $r3 = Robo (Join-Path $work 'claude-mem') $memDir
    }
} else {
    $r1 = Robo (Join-Path $work 'claude') $claudeDir
    # Copying over a database in use can corrupt it.
    Stop-ClaudeMemWorker
    $r3 = Robo (Join-Path $work 'claude-mem') $memDir
}
Say "claude settings/hooks/skills/memory : $(if ($r1) {'OK'} else {'FAILED'})"
Say "Orca agent-hooks                    : $(if ($r2) {'OK'} else {'FAILED'})"
Say "claude-mem                          : $(if ($r3) {'OK'} else {'FAILED'})"

# ---------- 5. rewrite paths ----------
Step '5/8  Rewrite old-machine paths'
$oldHome = $manifest.sourceHome                    # the source PC's home, or Aigoo's placeholder
$newHome = $TargetHome
$py = Find-Python313
$oldPy = $manifest.sourcePython                    # forward-slash form as used in settings.json

function Fix-File($path) {
    if (-not (Test-Path -LiteralPath $path)) { return }
    $t = [IO.File]::ReadAllText($path)
    $orig = $t
    $pairs = @(
        @(($oldHome -replace '\\', '/'), ($newHome -replace '\\', '/')),
        @(($oldHome -replace '\\', '\\'), ($newHome -replace '\\', '\\'))
    )
    if ($IsPublic) { $pairs += , @($oldHome, $newHome) }   # plain backslashes in .cmd / .ps1 files
    foreach ($p in $pairs) { $t = $t.Replace($p[0], $p[1]) }
    if ($py -and $oldPy) {
        $oldPyNew = $oldPy.Replace(($oldHome -replace '\\', '/'), ($newHome -replace '\\', '/'))
        $t = $t.Replace($oldPyNew, ($py -replace '\\', '/'))
    }
    if ($t -ne $orig) { Write-Utf8NoBom $path $t; Say "Updated $path" } else { Say "No change $path" 'DarkGray' }
}
Fix-File (Join-Path $claudeDir 'settings.json')
Fix-File (Join-Path $memDir 'settings.json')
if ($IsPublic) {
    # The public package carries a placeholder home in every file that named one.
    $textExt = '.json', '.cmd', '.ps1', '.py', '.md', '.txt'
    foreach ($d in (Join-Path $claudeDir 'hooks'), $orcaHooks) {
        Get-ChildItem -LiteralPath $d -File -ErrorAction SilentlyContinue |
            Where-Object { $textExt -contains $_.Extension.ToLower() } | ForEach-Object { Fix-File $_.FullName }
    }
}
if (-not $py) { Say 'Python 3.13 not found - the five-stage hook (stage_gate.py) will not run until it is installed.' 'Red' }

# ---------- 6. Orca ----------
$orcaExe = Join-Path $env:LOCALAPPDATA 'Programs\orca\Orca.exe'
if (-not $SkipApps) {
    Step '6/8  Orca'
    if ((Test-Path -LiteralPath $orcaExe) -and $Mode -ne 'Full') {
        Say 'Orca already installed - skip' 'DarkGray'
    } else {
        # winget first: it checks the installer's SHA256. In Full mode an Orca that is already
        # up to date makes winget return non-zero, and the official download reinstalls it.
        $orcaDone = $false
        if ($hasWinget) {
            $orcaDone = ((Invoke-Winget 'StablyAI.Orca' 'Orca') -eq 0) -and (Test-Path -LiteralPath $orcaExe)
            if (-not $orcaDone) { Say 'winget did not install Orca - trying the official download' 'Yellow' }
        }
        if (-not $orcaDone) {
            $setup = Join-Path $work 'orca-windows-setup.exe'
            $url = 'https://github.com/stablyai/orca/releases/latest/download/orca-windows-setup.exe'
            Say 'Orca setup is about 200 MB' 'DarkGray'
            try {
                Download-Verified $url $setup $null
                Say 'Installing Orca silently ...' 'Yellow'
                Start-Process -FilePath $setup -ArgumentList '/S' -Wait
            } catch {
                Say "Orca download/install failed: $($_.Exception.Message)" 'Red'
            }
        }
    }
}

# ---------- 7. claude-mem plugin ----------
if (-not $SkipApps) {
    Step '7/8  claude-mem plugin'
    if (Test-Path -LiteralPath $claudeExe) {
        & $claudeExe plugin marketplace add thedotmack/claude-mem 2>&1 | ForEach-Object { Say "$_" 'DarkGray' }
        & $claudeExe plugin install claude-mem@thedotmack 2>&1 | ForEach-Object { Say "$_" 'DarkGray' }
    } else {
        Say 'claude.exe missing - skip plugin install' 'Red'
    }
}

# ---------- 8. desktop shortcut ----------
$lnkPath = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Claude Code.lnk'
$wt = Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps\wt.exe'

# Point a shortcut at Windows Terminal: the legacy console (conhost) cannot show
# Chinese text or Claude's box-drawing symbols on a non-Chinese system locale.
function Set-ShortcutToTerminal($lnk, [string]$workDir) {
    # wt -d "X:\" breaks on the trailing backslash; use "X:\." for drive roots
    $d = $workDir.TrimEnd('\')
    if ($d -match ':$') { $d += '\.' }
    $lnk.TargetPath = $wt
    $lnk.Arguments = "-d `"$d`" `"$claudeExe`""
}

if ($NoShortcut) {
    # dry runs: leave the real Desktop shortcut alone
} elseif ($Mode -eq 'Patch' -and (Test-Path -LiteralPath $lnkPath)) {
    $kept = $true
    try {
        $lnk = (New-Object -ComObject WScript.Shell).CreateShortcut($lnkPath)
        $usesTerminal = (Split-Path -Leaf $lnk.TargetPath) -ieq 'wt.exe'
        if (-not $usesTerminal -and (Test-Path -LiteralPath $wt)) {
            $workDir = $lnk.WorkingDirectory
            if (-not $workDir -or -not (Test-Path -LiteralPath $workDir)) { $workDir = $TargetHome }
            Set-ShortcutToTerminal $lnk $workDir
            $lnk.WorkingDirectory = $workDir
            $lnk.Save()
            Say 'Desktop shortcut switched to Windows Terminal (the old console cannot show Chinese)'
            $kept = $false
        } elseif (-not $usesTerminal) {
            Say 'Desktop shortcut uses the old console and Windows Terminal is not installed - Chinese text may not show' 'Yellow'
        }
    } catch {
        Say "Could not check the Desktop shortcut: $($_.Exception.Message)" 'Yellow'
    }
    if ($kept) { Say 'Desktop shortcut already exists - keep it' 'DarkGray' }
} else {
    Step '8/8  Desktop shortcut (Claude Code)'
    $workDir = $TargetHome
    try {
        $owner = New-DialogOwner 'Aigo - choose the Claude start folder'
        $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
        $dlg.Description = 'Choose the folder Claude Code starts in (Cancel = your user folder)'
        $dlg.SelectedPath = $TargetHome
        $dlg.ShowNewFolderButton = $true
        if ($dlg.ShowDialog($owner) -eq [System.Windows.Forms.DialogResult]::OK -and $dlg.SelectedPath) {
            $workDir = $dlg.SelectedPath
        }
        $owner.Dispose()
    } catch {
        Say "Folder dialog failed - using $workDir" 'Yellow'
    }
    Say "Claude start folder: $workDir"
    try {
        $lnk = (New-Object -ComObject WScript.Shell).CreateShortcut($lnkPath)
        if (Test-Path -LiteralPath $wt) {
            Set-ShortcutToTerminal $lnk $workDir
            Say 'Shortcut uses Windows Terminal'
        } else {
            $lnk.TargetPath = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
            $lnk.Arguments = "-NoExit -NoLogo -Command `"& '$($claudeExe.Replace("'", "''"))'`""
            Say 'Windows Terminal not found - shortcut uses PowerShell'
        }
        $lnk.WorkingDirectory = $workDir
        if (Test-Path -LiteralPath $claudeExe) { $lnk.IconLocation = "$claudeExe,0" }
        $lnk.Description = 'Claude Code'
        $lnk.Save()
        Say "Created $lnkPath"
    } catch {
        Say "Desktop shortcut failed: $($_.Exception.Message)" 'Red'
    }
}

# ---------- checklist ----------
Refresh-Path
Write-Host ''
Write-Host '  CHECKLIST' -ForegroundColor White
$fail = 0
function Check($label, $ok, [switch]$Optional) {
    if ($ok) { Say ("[ OK ] " + $label) 'Green' }
    elseif ($Optional) { Say ("[WARN] " + $label) 'Yellow' }
    else { Say ("[FAIL] " + $label) 'Red'; $script:fail++ }
}
$settingsOk = $false
try { Get-Content -LiteralPath (Join-Path $claudeDir 'settings.json') -Raw | ConvertFrom-Json | Out-Null; $settingsOk = $true } catch {}
Check 'Git' ([bool](Get-Command git -ErrorAction SilentlyContinue))
Check 'Python 3.13' ([bool]$py)
Check 'Node.js' ([bool](Get-Command node -ErrorAction SilentlyContinue))
Check 'Bun (claude-mem)' ([bool](Get-Command bun -ErrorAction SilentlyContinue))
Check 'uv (claude-mem)' ([bool](Get-Command uv -ErrorAction SilentlyContinue)) -Optional
Check 'GitHub CLI (gh, for Orca)' ([bool](Get-Command gh -ErrorAction SilentlyContinue)) -Optional
Check 'Claude Code' (Test-Path -LiteralPath $claudeExe)
Check 'Orca' (Test-Path -LiteralPath $orcaExe)
if (-not $SkipApps) { Check 'RustDesk' (Test-Path -LiteralPath $rustDeskExe) }
Check "$Edition update hook" (Test-Path -LiteralPath (Join-Path $claudeDir 'hooks\aigo_update_check.ps1'))
Check 'settings.json parses' $settingsOk
Check 'CLAUDE.md' (Test-Path -LiteralPath (Join-Path $claudeDir 'CLAUDE.md'))
Check 'stage_gate.py hook' (Test-Path -LiteralPath (Join-Path $claudeDir 'hooks\stage_gate.py'))
Check 'Orca agent hook exe' (Test-Path -LiteralPath (Join-Path $orcaHooks 'orca-agent-hook.exe'))
if ($IsPublic) {
    # Aigoo ships no memory: claude-mem creates an empty database on the first Claude start.
    Check 'claude-mem database (created on first Claude start)' (Test-Path -LiteralPath (Join-Path $memDir 'claude-mem.db')) -Optional
} else {
    Check 'claude-mem database' (Test-Path -LiteralPath (Join-Path $memDir 'claude-mem.db'))
}
# The claude-mem plugin creates this launcher the first time Claude Code starts (it needs Bun),
# and its hooks call it by name, so a missing one shows as "Executable not found: claude-mem".
$cmemLauncher = Join-Path $env:LOCALAPPDATA 'claude-mem\bin\claude-mem.exe'
$cmemOk = (Test-Path -LiteralPath $cmemLauncher) -or [bool](Get-Command claude-mem -ErrorAction SilentlyContinue)
Check 'claude-mem launcher (created on first Claude start)' $cmemOk -Optional
if (-not (Get-Command bun -ErrorAction SilentlyContinue)) {
    Say '       claude-mem needs Bun, which is missing - run setup.cmd again to install it' 'Yellow'
}
$memCount = @(Get-ChildItem -LiteralPath (Join-Path $claudeDir 'projects') -Directory -ErrorAction SilentlyContinue |
    Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'memory') }).Count
if (-not $IsPublic) { Check "project memory folders ($memCount)" ($memCount -gt 0) -Optional }
if (-not $NoShortcut) { Check 'Desktop shortcut (Claude Code.lnk)' (Test-Path -LiteralPath $lnkPath) }

# Written only after every required check passes, so a failed update is tried again the next day.
if ($fail -eq 0) { Write-Utf8NoBom $versionMarker '1.17' }

Write-Host ''
Say 'Next steps:' 'White'
Say '  1. Close this window and open a NEW terminal (PATH changed).'
Say '  2. Double-click "Claude Code" on the Desktop (or run: claude), then type  /login'
Say '  3. Start Orca once so it re-registers its hooks.'
if ($IsPublic) {
    Say "  4. Updates are automatic: Claude Code checks $RepoWeb once a day (no sign-in needed)."
} else {
    Say "  4. For automatic $Edition updates, sign in to GitHub once. In a NEW terminal run:"
    Say "       git ls-remote $RepoWeb.git"
}
Say '  5. To use RustDesk with its public server, log in inside RustDesk first.'
Say '  6. After the first Claude start, open a NEW terminal again so the claude-mem hooks find claude-mem.exe.'
Say "  Log: $log"
if ($fail -gt 0) {
    Write-Host ''
    Say "INSTALL HAD $fail FAILURE(S)." 'Red'
    Say 'If the log shows a network error (504, 503, timeout), wait a few minutes and run the installer again:' 'Yellow'
    Say '  programs that are already installed are skipped. If it still fails, fix it from another PC:' 'Yellow'
    Say "  1. Open $issueUrl" 'Yellow'
    Say "  2. Attach the log file above (it contains this PC's name, user name and paths)" 'Yellow'
    Say '  3. On the other PC, ask Claude Code to read the issue and fix it' 'Yellow'
}

Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
Stop-Transcript | Out-Null
exit $fail
